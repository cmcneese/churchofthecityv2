<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_icon-list-item/icon-list-item.php';
