<div class="qode_content_slider_item">
    <?php echo do_shortcode($content); ?>
</div>